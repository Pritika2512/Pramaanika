import { useCallback, useMemo, useState } from "react";
import { ArrowLeft, CheckCircle2, Copy, Download, ExternalLink, Printer, ShieldCheck, XCircle } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import {
  getCertificateById,
  updateCertificateBlockchain,
} from "../../services/certificateService.js";
import {
  anchorCertificateOnBlockchain,
  blockchainExplorerUrl,
  verifyCertificateOnBlockchain,
  revokeCertificateOnBlockchain,
} from "../../services/blockchainService.js";
import { getInstrumentById } from "../../services/instrumentService.js";
import { useResource } from "../../hooks/useResource.js";
import { Breadcrumb, Button, Card, EmptyState, ErrorState, LoadingState, PageHeader, StatusBadge } from "../../components/common/ui.jsx";
import { formatDate, optionLabel } from "../../utils/format.js";
import { instrumentTypes } from "../../config/instrumentConfig.js";

export default function CertificateDetails(){
 const {id}=useParams(); const nav=useNavigate();
 const [anchoring, setAnchoring] = useState(false);
 const [checking, setChecking] = useState(false);
 const [blockchainMessage, setBlockchainMessage] = useState("");
 const [blockchainVerified, setBlockchainVerified] = useState(null);
 const load=useCallback(async()=>{const certificate=await getCertificateById(id);return certificate?{certificate,instrument:await getInstrumentById(certificate.instrumentId)}:null},[id]);
 const {data,loading,error,reload}=useResource(load);
 const verifyUrl=useMemo(()=>`${window.location.origin}/verify/${encodeURIComponent(id)}`,[id]);
 if(loading)return <LoadingState/>;if(error)return <ErrorState message={error} retry={reload}/>;if(!data)return <EmptyState title="Certificate not found" description="This certificate record is unavailable." action={<Button to="/certificates">Back to certificates</Button>}/>;
 const {certificate,instrument}=data;
 function copyLink(){navigator.clipboard?.writeText(verifyUrl);}

 async function anchor() {
   setAnchoring(true);
   setBlockchainMessage("");
   try {
     const result = await anchorCertificateOnBlockchain(certificate, instrument);
     await updateCertificateBlockchain(certificate.id, {
       blockchainStatus: "CONFIRMED",
       hash: result.certificateHash,
       transactionId: result.transactionId,
       blockchainNetwork: result.network,
       blockchainIssuer: result.issuer,
     });
     setBlockchainMessage("Certificate fingerprint was anchored successfully.");
     reload();
   } catch (err) {
     setBlockchainMessage(err.message);
   } finally {
     setAnchoring(false);
   }
 }

 async function revokeOnChain() {
   const confirmed = window.confirm(
     "Revoke this certificate on blockchain? This action is permanent on-chain.",
   );
   if (!confirmed) return;
   setChecking(true);
   setBlockchainMessage("");
   try {
     const result = await revokeCertificateOnBlockchain(certificate);
     await updateCertificateBlockchain(certificate.id, {
       blockchainStatus: "CONFIRMED",
       status: "REVOKED",
       transactionId: result.transactionId,
     });
     setBlockchainMessage("Certificate was revoked on blockchain.");
     reload();
   } catch (err) {
     setBlockchainMessage(err.message);
   } finally {
     setChecking(false);
   }
 }

 async function verifyOnChain() {
   setChecking(true);
   setBlockchainMessage("");
   try {
     const result = await verifyCertificateOnBlockchain(certificate, instrument);
     setBlockchainVerified(result);
     setBlockchainMessage(
       result.verified
         ? "Blockchain verification passed."
         : result.reason || "Blockchain verification failed.",
     );
   } catch (err) {
     setBlockchainVerified({ verified: false });
     setBlockchainMessage(err.message);
   } finally {
     setChecking(false);
   }
 }
 return <div className="certificate-page"><Breadcrumb items={[{label:"Certificates",to:"/certificates"},{label:certificate.id}]}/><PageHeader title={certificate.id} description="Digital certificate of verification." actions={<Button variant="secondary" onClick={()=>nav("/certificates")}><ArrowLeft size={17}/>Back</Button>}/>
   <div className="certificate-actions"><Button onClick={()=>window.print()}><Printer size={17}/>Print</Button><Button variant="secondary" onClick={()=>window.print()}><Download size={17}/>Download / Save PDF</Button><Button variant="secondary" onClick={copyLink}><Copy size={17}/>Copy verification link</Button>
   {certificate.blockchainStatus !== "CONFIRMED" && <Button onClick={anchor} loading={anchoring}><ShieldCheck size={17}/>Anchor on blockchain</Button>}
   {certificate.blockchainStatus === "CONFIRMED" && <Button variant="secondary" onClick={verifyOnChain} loading={checking}><ShieldCheck size={17}/>Verify on blockchain</Button>}
   {certificate.blockchainStatus === "CONFIRMED" && certificate.status === "ACTIVE" && <Button variant="secondary" onClick={revokeOnChain} loading={checking}><XCircle size={17}/>Revoke on blockchain</Button>}
   </div>
   {blockchainMessage && <div className={"blockchain-result " + (blockchainVerified?.verified ? "is-valid" : "")}>{blockchainVerified?.verified ? <CheckCircle2 size={20}/> : <ShieldCheck size={20}/>}<span>{blockchainMessage}</span></div>}
   <Card className="certificate-shell"><div className="certificate-document" id="certificate-print"><div className="certificate-top"><div className="certificate-brand"><span className="certificate-mark"><ShieldCheck size={27}/></span><div><strong>MeasureSure</strong><small>Legal Metrology Verification System</small></div></div><StatusBadge status={certificate.status}/></div><div className="certificate-heading"><span>OFFICIAL DIGITAL RECORD</span><h2>Certificate of Verification</h2><p>Online Verification System for Weighing &amp; Measuring Instruments</p></div><div className="certificate-id"><span>Certificate ID</span><strong>{certificate.id}</strong></div><div className="certificate-grid"><section><h3>Instrument information</h3><dl><div><dt>Instrument ID</dt><dd>{instrument?.id}</dd></div><div><dt>Type</dt><dd>{optionLabel(instrumentTypes,instrument?.type)}</dd></div><div><dt>Manufacturer</dt><dd>{instrument?.manufacturer}</dd></div><div><dt>Model</dt><dd>{instrument?.model}</dd></div><div><dt>Serial number</dt><dd>{instrument?.serialNumber}</dd></div><div><dt>Capacity</dt><dd>{instrument?.capacity}</dd></div><div><dt>Accuracy</dt><dd>{instrument?.accuracy}</dd></div></dl></section><section><h3>Owner &amp; verification</h3><dl><div><dt>Owner</dt><dd>{instrument?.owner}</dd></div><div><dt>Location</dt><dd>{instrument?.location}</dd></div><div><dt>Verified on</dt><dd>{formatDate(certificate.issueDate)}</dd></div><div><dt>Valid until</dt><dd>{formatDate(certificate.validUntil)}</dd></div><div><dt>Inspector</dt><dd>{certificate.inspector}</dd></div><div><dt>Status</dt><dd><StatusBadge status={certificate.status}/></dd></div></dl></section></div><div className="certificate-footer-grid"><div className="qr-placeholder"><div className="qr-pattern">▦</div><div><strong>Scan to verify</strong><small>Public verification record</small><a href={verifyUrl}>{verifyUrl}</a></div></div><div className="blockchain-record"><div><CheckCircle2 size={20}/><strong>Blockchain record</strong></div><span>Status: {certificate.blockchainStatus}</span><span>Certificate hash: {certificate.hash}</span><span>Transaction ID: {certificate.transactionId}</span>
   {certificate.transactionId?.startsWith("0x") && <a className="record-link" href={blockchainExplorerUrl(certificate.transactionId)} target="_blank" rel="noreferrer">View on block explorer ↗</a>}
   </div></div><p className="certificate-note">Blockchain anchoring stores a tamper-evident fingerprint of this certificate. The certificate document and business data remain off-chain.</p></div></Card></div>;
}
