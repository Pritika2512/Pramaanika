import { useCallback, useState } from "react";
import { CheckCircle2, ExternalLink, ShieldCheck, XCircle } from "lucide-react";
import { useParams } from "react-router-dom";
import {
  getPublicCertificateById,
} from "../../services/certificateService.js";
import { getPublicInstrumentById } from "../../services/instrumentService.js";
import { verifyCertificateOnBlockchain, blockchainExplorerUrl } from "../../services/blockchainService.js";
import { useResource } from "../../hooks/useResource.js";
import { Button, Card, ErrorState, LoadingState, StatusBadge } from "../../components/common/ui.jsx";
import { formatDate, optionLabel } from "../../utils/format.js";
import { instrumentTypes } from "../../config/instrumentConfig.js";

export default function PublicCertificateVerification() {
  const { id } = useParams();
  const [verification, setVerification] = useState(null);
  const [checking, setChecking] = useState(false);

  const load = useCallback(async () => {
    const certificate = await getPublicCertificateById(id);
    if (!certificate) return null;
    const instrument = await getPublicInstrumentById(certificate.instrumentId);
    return { certificate, instrument };
  }, [id]);

  const { data, loading, error } = useResource(load);

  async function verify() {
    if (!data) return;
    setChecking(true);
    try {
      setVerification(await verifyCertificateOnBlockchain(data.certificate, data.instrument));
    } catch (err) {
      setVerification({ configured: true, verified: false, reason: err.message });
    } finally {
      setChecking(false);
    }
  }

  if (loading) return <LoadingState label="Loading public certificate…" />;
  if (error) return <ErrorState message={error} />;
  if (!data) {
    return (
      <div className="standalone-state">
        <Card>
          <div className="state-panel">
            <XCircle size={32} />
            <h3>Certificate not found</h3>
            <p>The verification record does not exist in this demonstration system.</p>
          </div>
        </Card>
      </div>
    );
  }

  const { certificate, instrument } = data;
  const txUrl = blockchainExplorerUrl(certificate.transactionId);

  return (
    <div className="standalone-state public-verify-page">
      <Card>
        <div className="public-verify-header">
          <span className="certificate-mark"><ShieldCheck size={30} /></span>
          <div>
            <strong>MeasureSure</strong>
            <p>Public Certificate Verification</p>
          </div>
        </div>

        <div className="public-verify-summary">
          <span className="record-emblem">
            {verification?.verified ? <CheckCircle2 size={42} /> : <ShieldCheck size={42} />}
          </span>
          <h1>{verification?.verified ? "Certificate is authentic" : "Verify this certificate"}</h1>
          <p>
            Certificate <strong>{certificate.id}</strong>
          </p>
          <StatusBadge status={certificate.status} />
        </div>

        <dl className="details-grid">
          <div><dt>Instrument ID</dt><dd>{certificate.instrumentId}</dd></div>
          <div><dt>Instrument type</dt><dd>{optionLabel(instrumentTypes, instrument?.type)}</dd></div>
          <div><dt>Manufacturer</dt><dd>{instrument?.manufacturer || "—"}</dd></div>
          <div><dt>Model</dt><dd>{instrument?.model || "—"}</dd></div>
          <div><dt>Verified on</dt><dd>{formatDate(certificate.issueDate)}</dd></div>
          <div><dt>Valid until</dt><dd>{formatDate(certificate.validUntil)}</dd></div>
          <div><dt>Inspector</dt><dd>{certificate.inspector}</dd></div>
          <div><dt>Blockchain</dt><dd>{certificate.blockchainStatus || "PENDING"}</dd></div>
        </dl>

        <div className="public-verify-actions">
          <Button onClick={verify} loading={checking}>
            <ShieldCheck size={17} />
            {checking ? "Checking blockchain…" : "Verify on blockchain"}
          </Button>
          {txUrl && (
            <a className="button button-secondary" href={txUrl} target="_blank" rel="noreferrer">
              <ExternalLink size={17} /> View transaction
            </a>
          )}
        </div>

        {verification && (
          <div className={`blockchain-result ${verification.verified ? "is-valid" : "is-invalid"}`}>
            {verification.verified ? <CheckCircle2 size={22} /> : <XCircle size={22} />}
            <div>
              <strong>{verification.verified ? "Blockchain verification passed" : "Blockchain verification failed"}</strong>
              <p>
                {verification.reason ||
                  (verification.revoked
                    ? "This certificate has been revoked on-chain."
                    : "The stored blockchain fingerprint does not match this certificate.")}
              </p>
              {verification.certificateHash && <small>Hash: {verification.certificateHash}</small>}
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
