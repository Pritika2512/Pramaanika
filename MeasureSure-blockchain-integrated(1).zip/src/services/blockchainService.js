import {
  BrowserProvider,
  Contract,
  JsonRpcProvider,
  sha256,
  toUtf8Bytes,
} from "ethers";
import { blockchainConfig, blockchainConfigured } from "../config/blockchainConfig.js";

export const CERTIFICATE_REGISTRY_ABI = [
  "function registerCertificate(bytes32 certificateIdHash, bytes32 certificateHash, bytes32 instrumentHash, uint64 validUntil)",
  "function revokeCertificate(bytes32 certificateIdHash)",
  "function getCertificate(bytes32 certificateIdHash) view returns (tuple(bytes32 certificateHash, bytes32 instrumentHash, uint64 issuedAt, uint64 validUntil, address issuer, bool revoked, bool exists))",
  "function verifyCertificate(bytes32 certificateIdHash, bytes32 certificateHash) view returns (bool)",
  "function authorizedIssuers(address) view returns (bool)",
];

function assertConfigured() {
  if (!blockchainConfigured) {
    throw new Error(
      "Blockchain is not configured yet. Add VITE_BLOCKCHAIN_CONTRACT_ADDRESS and VITE_BLOCKCHAIN_RPC_URL to .env.local.",
    );
  }
}

function canonicalCertificate(certificate, instrument) {
  return JSON.stringify({
    certificateId: certificate.id,
    instrumentId: certificate.instrumentId,
    issueDate: certificate.issueDate,
    validUntil: certificate.validUntil,
    status: certificate.status,
    inspector: certificate.inspector,
    instrument: {
      id: instrument?.id || "",
      type: instrument?.type || "",
      manufacturer: instrument?.manufacturer || "",
      model: instrument?.model || "",
      serialNumber: instrument?.serialNumber || "",
      capacity: instrument?.capacity || "",
      accuracy: instrument?.accuracy || "",
      owner: instrument?.owner || "",
      location: instrument?.location || "",
    },
  });
}

export function hashCertificate(certificate, instrument) {
  return sha256(toUtf8Bytes(canonicalCertificate(certificate, instrument)));
}

export function hashCertificateId(certificateId) {
  return sha256(toUtf8Bytes(`MeasureSure:${certificateId}`));
}

export function hashInstrument(instrumentId) {
  return sha256(toUtf8Bytes(`MeasureSure:Instrument:${instrumentId}`));
}

function validUntilTimestamp(dateString) {
  const timestamp = Math.floor(new Date(`${dateString}T23:59:59`).getTime() / 1000);
  if (!Number.isFinite(timestamp) || timestamp <= 0) {
    throw new Error("Invalid certificate validity date.");
  }
  return timestamp;
}

export async function connectBlockchainWallet() {
  if (!window.ethereum) {
    throw new Error("MetaMask is required to write certificate records to the blockchain.");
  }

  assertConfigured();

  const provider = new BrowserProvider(window.ethereum);
  await provider.send("eth_requestAccounts", []);
  const network = await provider.getNetwork();

  if (Number(network.chainId) !== blockchainConfig.chainId) {
    throw new Error(
      `Wrong network. Please switch MetaMask to ${blockchainConfig.chainName} (chain ID ${blockchainConfig.chainId}).`,
    );
  }

  const signer = await provider.getSigner();
  return { provider, signer, address: await signer.getAddress() };
}

export async function getReadOnlyRegistry() {
  assertConfigured();

  if (!blockchainConfig.rpcUrl) {
    throw new Error("VITE_BLOCKCHAIN_RPC_URL is missing.");
  }

  const provider = new JsonRpcProvider(blockchainConfig.rpcUrl, blockchainConfig.chainId);
  return new Contract(
    blockchainConfig.contractAddress,
    CERTIFICATE_REGISTRY_ABI,
    provider,
  );
}

export async function anchorCertificateOnBlockchain(certificate, instrument) {
  const { signer, address } = await connectBlockchainWallet();
  const contract = new Contract(
    blockchainConfig.contractAddress,
    CERTIFICATE_REGISTRY_ABI,
    signer,
  );

  const certificateHash = hashCertificate(certificate, instrument);
  const certificateIdHash = hashCertificateId(certificate.id);
  const instrumentHash = hashInstrument(certificate.instrumentId);
  const validUntil = validUntilTimestamp(certificate.validUntil);

  const isIssuer = await contract.authorizedIssuers(address);
  if (!isIssuer) {
    throw new Error(
      "This wallet is not an authorized MeasureSure issuer. Authorize it from the contract owner account first.",
    );
  }

  const transaction = await contract.registerCertificate(
    certificateIdHash,
    certificateHash,
    instrumentHash,
    validUntil,
  );

  const receipt = await transaction.wait();

  return {
    certificateHash,
    certificateIdHash,
    transactionId: receipt.hash,
    issuer: address,
    network: blockchainConfig.chainName,
    explorerUrl: `${blockchainConfig.explorerUrl}/tx/${receipt.hash}`,
  };
}

export async function verifyCertificateOnBlockchain(certificate, instrument) {
  if (!blockchainConfigured || !blockchainConfig.rpcUrl) {
    return {
      configured: false,
      verified: false,
      reason: "Blockchain is not configured.",
    };
  }

  const contract = await getReadOnlyRegistry();
  const certificateHash = hashCertificate(certificate, instrument);
  const certificateIdHash = hashCertificateId(certificate.id);
  const record = await contract.getCertificate(certificateIdHash);

  if (!record.exists) {
    return {
      configured: true,
      verified: false,
      found: false,
      certificateHash,
      certificateIdHash,
      reason: "Certificate is not anchored on this blockchain.",
    };
  }

  const verified = await contract.verifyCertificate(
    certificateIdHash,
    certificateHash,
  );

  return {
    configured: true,
    verified,
    found: true,
    revoked: record.revoked,
    expired:
      Number(record.validUntil) * 1000 < Date.now(),
    certificateHash,
    certificateIdHash,
    issuer: record.issuer,
    issuedAt: Number(record.issuedAt),
    validUntil: Number(record.validUntil),
  };
}


export async function revokeCertificateOnBlockchain(certificate) {
  const { signer } = await connectBlockchainWallet();
  const contract = new Contract(
    blockchainConfig.contractAddress,
    CERTIFICATE_REGISTRY_ABI,
    signer,
  );
  const certificateIdHash = hashCertificateId(certificate.id);
  const transaction = await contract.revokeCertificate(certificateIdHash);
  const receipt = await transaction.wait();

  return {
    transactionId: receipt.hash,
    explorerUrl: `${blockchainConfig.explorerUrl}/tx/${receipt.hash}`,
  };
}

export function blockchainExplorerUrl(transactionId) {
  if (!transactionId || !transactionId.startsWith("0x")) return "";
  return `${blockchainConfig.explorerUrl}/tx/${transactionId}`;
}
