import test from "node:test";
import assert from "node:assert/strict";
import { appConfig } from "../src/config/appConfig.js";
import * as auth from "../src/services/authService.js";
import * as instruments from "../src/services/instrumentService.js";
import * as users from "../src/services/userService.js";
import { getDashboardStats } from "../src/services/dashboardService.js";
import { mockInstruments } from "../src/data/mockInstruments.js";
import { mockUsers } from "../src/data/mockUsers.js";

// Exercise the service boundary without a browser or extra dependencies.
appConfig.serviceDelay = 0;
test("mock services stay consistent", async (t) => {
  await t.test("signed-out and inactive accounts are rejected", async () => {
    auth.logout();
    await assert.rejects(instruments.getInstruments, /Sign in/);
    await assert.rejects(
      () => auth.login({ email: "admin@example.com", password: "wrong" }),
      /incorrect/,
    );
    await assert.rejects(
      () =>
        auth.login({ email: "vikram@example.com", password: "password123" }),
      /inactive/,
    );
  });
  await t.test("inspector manages instruments but not users", async () => {
    const inspector = await auth.login({
      email: "inspector@example.com",
      password: "password123",
    });
    assert.equal(inspector.role, "INSPECTOR");
    assert.equal("password" in inspector, false);
    await assert.rejects(users.getUsers, /Administrator/);
    const original = mockInstruments[0];
    await assert.rejects(
      () => instruments.createInstrument(original),
      /already registered/,
    );
    const created = await instruments.createInstrument({
      ...original,
      serialNumber: "TEST-UNIQUE-001",
    });
    assert.notEqual(created.id, original.id);
    assert.equal(created.status, "PENDING");
    await instruments.updateInstrument(created.id, {
      ...created,
      model: "Updated model",
    });
    assert.equal(
      (await instruments.getInstrumentById(created.id)).model,
      "Updated model",
    );
    const dashboard = await getDashboardStats();
    assert.equal(dashboard.stats.total, mockInstruments.length + 1);
    assert.equal(
      dashboard.stats.pending,
      mockInstruments.filter((i) => i.status === "PENDING").length + 1,
    );
    assert.equal("totalUsers" in dashboard.stats, false);
  });
  await t.test(
    "admin adds, edits, deactivates and reactivates users",
    async () => {
      await auth.login({ email: "admin@example.com", password: "password123" });
      await assert.rejects(
        () => users.createUser(mockUsers[0]),
        /already exists/,
      );
      const created = await users.createUser({
        ...mockUsers[1],
        name: "Test User",
        email: "test@example.com",
      });
      assert.equal("password" in created, false);
      assert.equal(
        (
          await users.updateUser(created.id, {
            ...created,
            name: "Updated User",
          })
        ).name,
        "Updated User",
      );
      assert.equal(
        (await users.toggleUserStatus(created.id)).status,
        "INACTIVE",
      );
      assert.equal((await users.toggleUserStatus(created.id)).status, "ACTIVE");
      await assert.rejects(
        () => users.toggleUserStatus("USR-001"),
        /own account/,
      );
      await assert.rejects(
        () =>
          users.updateUser("USR-001", { ...mockUsers[0], role: "INSPECTOR" }),
        /own administrator/,
      );
      assert.equal(
        (await getDashboardStats()).stats.totalUsers,
        mockUsers.length + 1,
      );
    },
  );
  await t.test(
    "self-registration creates a usable inspector account",
    async () => {
      auth.logout();
      const values = {
        ...mockUsers[1],
        name: "New Inspector",
        email: "new@example.com",
        password: "Student123!",
        confirmPassword: "Student123!",
        role: "ADMIN",
      };
      const created = await auth.register(values);
      assert.equal(created.role, "INSPECTOR");
      assert.equal("password" in created, false);
      assert.equal((await auth.login(values)).id, created.id);
      await assert.rejects(() => auth.register(values), /already exists/);
      await assert.rejects(users.getUsers, /Administrator/);
      auth.logout();
    },
  );
});
